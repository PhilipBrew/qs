module.exports = {
	mongoURI : "mongodb+srv://mw-qsportal:5BYowpz5puFL3ulW@mw-qsportal-5ehzu.mongodb.net/test?retryWrites=true",
	secretKey : "helloworld",
	cryptr : "SGvrOY9qOVTEGEfOdAYZ7d5g.216rVCIvImCI5V26w1JMTHxRm63HwUM5TJuOe_"
};